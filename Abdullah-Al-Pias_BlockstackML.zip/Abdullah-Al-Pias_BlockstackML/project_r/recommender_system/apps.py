from django.apps import AppConfig


class RecommenderSystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'recommender_system'
